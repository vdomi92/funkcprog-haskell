import Prelude hiding (map,
                       concatMap,
                       enumFromThenTo,
                       numericEnumFrom,
                       numericEnumFromThen,
                       numericEnumFromThenTo,
                       and)
-----------------------
-- Ismetles - listak --
-----------------------

-- lista literalok

-- stringek

-- hanyfele lista letezik?

--------------
-- rekurzio --
--------------

tl :: [a] -> [a]
tl []     = error "Empty list"
tl (x:xs) = xs

-- szorozzunk meg minden elemet egy listaban 2-vel

doubleList []     = []
-- doubleList []     = error "Empty"
doubleList (x:xs) = 2 * x : doubleList xs

{-
  doubleList [1,2,3] = doubleList (1:[2,3]) ->
  2 * 1 : doubleList [2,3] = 2 * 1 : doubleList (2:[3]) ->
  2 * 1 : (2 * 2 : doubleList [3]) = 2 * 1 : (2 * 2 : doubleList (3:[])) ->
  2 * 1 : (2 * 2 : (2 * 3 : doubleList [])) ->
  2 * 1 : (2 * 2 : (2 * 3 : [])) ->
  [2,4,6]
-}

double x = 2 * x

-- map
map :: (a -> b) -> [a] -> [b]
map f []     = []
map f (x:xs) = f x  : map f xs


and :: [Bool] -> Bool
and []     = True
and (x:xs) = x && and xs

-----------------------------
-- Intervallum kifejezesek --
-----------------------------


-- Hogyan tudnank megadni intervallum kifejezeseket rekurzivan?

-- majdnem jo:
myEnumFromTo' :: Int -> Int -> [Int]
myEnumFromTo' n m =
   if m < n
   then []
   else m : myEnumFromTo' n (m - 1)

myEnumFromTo'' :: Int -> Int -> [Int]
myEnumFromTo'' n m =
   if m < n
   then []
   else myEnumFromTo'' n (m - 1) ++ [m]

myEnumFromTo :: Int -> Int -> [Int]
myEnumFromTo n m =
   if m < n
   then []
   else n : myEnumFromTo (n + 1) m


numericEnumFromThenTo1 n1 n2 m =
   if m < n1
   then []
   else n1 : numericEnumFromThenTo1 (n1 + d) (n2 + d) m
-- | d >= 0 && m < n1    = []
-- | d < 0 && n1 < m = []
-- | otherwise = n1 : numericEnumFromThenTo1 (n1 + d) (n2 + d) m
  where
   d = n2 - n1

f x = d
  where
    d = 5 * x

f' x = let d = 5 * x in d

numericEnumFromThen n1 n2 = n1 : numericEnumFromThen n2 (n2 + d)
  where
    d = n2 - n1

numericEnumFromThenTo2 n1 n2 m = take k l
  where
    l = numericEnumFromThen n1 n2
    k = div (m - n1 + 1) d
    d = n2 - n1

numericEnumFromThenTo n1 n2 m = takeWhile comp l
  where
    l = numericEnumFromThen n1 n2
    d = n2 - n1
    comp = if d < 0 then (>= m + d / 2) else (<= m + d / 2)
-- Milyen tipusokra lehet irni intervallum kifejezest?



-- standard fuggvenyek intervallum kifejezesekhez


----------------------
-- listageneratorok --
----------------------


