import Prelude hiding (map, filter, concatMap)

map :: (a -> b) -> [a] -> [b]
map f []     = []
map f (x:xs) = f x : map f xs

filter :: (a -> Bool) -> [a] -> [a]
filter p []     = []
--filter p (x:xs) = if p x then x:filter p xs else filter p xs
filter p (x:xs) | p x = x:filter p xs
                | otherwise = filter p xs
                
concatMap :: (a -> [b]) -> [a] -> [b]
concatMap f [] = []
concatMap f (x:xs) = f x ++ concatMap f xs

listcomp1 = [2*x | x <- [1..10], even x]

listcomp2 = let ok x = [ 2*x | even x ]
                ok _ = []
            in concatMap ok [1..10]

listcomp3 = let ok x = [ 2*x | even x, True ]
                ok _ = []
            in concatMap ok [1..10]

listcomp4 = let ok x = if even x then [ 2*x | True ] else []
                ok _ = []
            in concatMap ok [1..10]
            
listcomp5 = let ok x = if even x then [ 2*x ] else []
                ok _ = []
            in concatMap ok [1..10]
