import Prelude hiding (sum, foldr, foldl)

sum [] = 0
sum (x:xs) = x + sum xs

{-
sum [1,2,3] => 
  1 + sum [2,3] =>
  1 + (2 + sum [3]) =>
  1 + (2 + (3 + sum [])) =>
  1 + (2 + (3 + 0)) =>
  ...
  6
-}

sumr z [] = z
sumr z (x:xs) = x + sumr z xs

foldr :: (a -> b -> b) -> b -> [a] -> b 
foldr f z [] = z
foldr f z (x:xs) = x `f` foldr f z xs

suml z [] = z
suml z (x:xs) = suml (z + x) xs

foldl :: (b -> a -> b) -> b -> [a] -> b
foldl f z [] = z
foldl f z (x:xs) = foldl f (z `f` x) xs

{-
suml 0 [1,2,3] =>
  suml (0+1) [2,3] =>
  suml ((0+1)+2) [3] =>
  suml (((0+1)+2)+3) [] =>
  ((0+1)+2)+3
-}

alleven [] = True
alleven (x:xs) = even x && alleven xs

alleven' z [] = z
alleven' z (x:xs) = alleven' (z && even x) xs

{-
alleven' True [1,2,3] => *

  alleven' (True && even 1 && even 2 && even 3) []
  True && even 1 && even 2 && even 3
-}

--          (:)          
id' = foldr (\x xs -> x : xs) []
reverse' = foldl (flip (:)) []

--map' :: (a -> b) -> [a] -> [b]
--map' f = foldr (\x xs -> f x : xs) []
--map' f = foldr (\x -> (:) (f x)) []
--map' f = foldr (\x -> ((:) . f) x) []
map' f = foldr ((:) . f) []
filter' p = foldr (\x xs -> if p x then x:xs else xs) []

